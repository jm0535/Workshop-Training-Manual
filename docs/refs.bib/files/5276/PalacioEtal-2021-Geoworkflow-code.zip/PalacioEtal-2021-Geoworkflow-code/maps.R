#Load packages
pacman::p_load(rio, here, sf, raster, tmap, tmaptools, OpenStreetMap, rJava)

##NOTE: You need to have Java Runtime Environment installed to download map tiles
#https://www.java.com/en/download/manual.jsp

#create directory to hold maps
map_figures <- here("maps")
dir.create(map_figures)

#import csv of birds
sp <- unlist(read.csv(here("data", "forest-birds.csv")))

#birdlife ranges
birdlife.ranges <- st_read(here("data", "forest-birds.gpkg")) %>%
  st_transform("ESRI:54012")

for (i in seq_along(sp)) {
  print(sp[i])
  
  bird.name <- sp[i] %>% stringr::str_replace(pattern = " ", replacement = "_")
  
  # import datasets ---------------------------------------------------------
  
  #import presences
  presences <- st_read(here("output", paste0(bird.name, "_presences.gpkg"))) %>% 
    st_set_crs("ESRI:54012")
  
  #import presences
  absences <- st_read(here("output", paste0(bird.name, "_absences.gpkg"))) %>% 
    st_set_crs("ESRI:54012")
  
  sp.mcp <- st_read(here("output", paste0(bird.name, "_EOO.gpkg")))
  
  #import species range
  sp.range.poly <- st_read(here("output", paste0(bird.name, "_IDW_range.gpkg"))) %>% 
    st_set_crs("ESRI:54012")
  
  sp.range <- raster(here("output", paste0(bird.name, "_IDW_range.tif")))
  
  sp.AOH <- raster(here("output", paste0(bird.name, "_AOH.tif")))
  
  sp.birdlife <- dplyr::filter(birdlife.ranges, binomial ==  sp[i])
  
  # set drawing box ---------------------------------------------------------
  
  #set bounding box of reproducible range
  range.box <- st_as_sfc(st_bbox(sp.range.poly))
  
  #set bounding box of birdlife range
  sp.birdlife.box <- st_as_sfc(st_bbox(sp.birdlife))
  
  #union both bounding boxes - read_osm requires wgs84
  sp.extent <- st_union(range.box, sp.birdlife.box)
  sp.extent.wgs84 <- st_transform(sp.extent,
                                  "+proj=longlat +ellps=WGS84 +towgs84=0,0,0,-0,-0,-0,0 +no_defs")
  
  #This function requires Java Runtime Environment
  sp.extent.geo <- tmaptools::read_osm(bb(sp.extent.wgs84, ext = 1.2, relative = TRUE), 
                                       type = "esri-topo", mergeTiles = TRUE)
  
  
  print(paste0(sp[i], "_done processing layers for mapping"))
  
  #plotting ---------------------------------------------------------------
  
  #plot EOO
  mcp.plot <- tm_shape(sp.mcp) +tm_borders(col = 'blue', lty = 2)
  
  #plot presences
  presences.plot <- tm_shape(presences) + 
    tm_bubbles(size = 0.075, col = 'yellow', border.col = 'black')
  
  #plot absences
  absences.plot <- tm_shape(absences) + tm_squares(size = 0.075, col = 'red')
  
  #plot birdlife range
  birdlife.plot <- tm_shape(sp.birdlife) + tm_borders(col = 'black', lwd = 2)
  
  #plot ESRI topographic base
  esri.base <- tm_shape(sp.extent.geo) + tm_rgb()
  
  #plot IDW range
  idw_range <- tm_shape(sp.range) + 
    tm_raster(alpha = 0.8, palette = '#B2B2B2', legend.show = FALSE)
  
  #plot AOH
  AOH.plot <- tm_shape(sp.AOH) + tm_raster(alpha = 0.8, palette = '#38a800', legend.show = FALSE)
  
  #final map for AOH
  map.sp <- esri.base + idw_range + AOH.plot + absences.plot +
    birdlife.plot + presences.plot + mcp.plot +
    tm_layout(main.title = sp[i], main.title.size = 1, main.title.position = 'center')
  
  #save as png
  tmap_save(map.sp,
            filename = here("maps", paste0(sp[i], "_plot.png")))
  
  
  print(paste0(sp[i], "_done making maps"))
  
  
  removeTmpFiles(h=0)
  terra::tmpFiles(remove=TRUE)
  
}

