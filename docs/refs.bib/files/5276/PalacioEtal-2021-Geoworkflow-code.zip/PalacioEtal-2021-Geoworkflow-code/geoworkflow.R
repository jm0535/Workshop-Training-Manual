#load packages
pacman::p_load(here, rio, sf, dismo, spex, tidyverse, fasterize, purrr, gstat, terra, raster)

geo_outputs <- here("output")
dir.create(geo_outputs)

# read data ---------------------------------------------------------------


##data available from Dryad for nine forest birds to run the geoworkflow
#in central America and the Caribbean
#https://doi.org/10.5061/dryad.9cnp5hqjm

#import csv of birds occurrence
birds <- list.files(path = here("data", "occ_data"), pattern = "csv")

#import dem and habitat layer
habitat <- terra::rast(here("data", "Forest_layer_TanDEM-X.tif"))
dem <- terra::rast(here("data", "SRTM_W_250m_eck4.tif"))

#import eBird hotspots for the Americas
hotspots <- sf::st_read(here("data", "ebird_hotspots_2021.gpkg")) 

#aggregate to 5 km
dggs <- dggridR::dgconstruct(spacing = 5)

datalist = list()

for (a in 1:length(birds)) {
  
  print(birds[a])
  
  bird.name <- tools::file_path_sans_ext(birds[a]) %>% 
    str_replace(pattern = " ", replacement = "_")
  
  sp.occ <- rio::import(here("data", "occ_data", birds[a])) %>% 
    dplyr::select("longitude", "latitude")
  
  sp.occ$cell <- dggridR::dgGEO_to_SEQNUM(dggs, sp.occ$longitude, sp.occ$latitude)$seqnum
  
  sp.occ.5km <- sp.occ %>% 
    group_by(cell) %>% 
    sample_n(size = 1) %>% 
    ungroup()
 
  # create MCP (Minimum Convex Polygon) -------------------------------------
  
  sp.occ.sf <- st_as_sf(sp.occ.5km, coords = c("longitude", "latitude"), crs = "EPSG:4326") %>% 
    st_transform("ESRI:54012")
  sp.mcp <- st_sf(st_convex_hull(st_union(sp.occ.sf)))
  st_write(sp.mcp, here("output", paste0(bird.name, "_EOO.gpkg")), delete_layer = TRUE)
  
  # Generate absences -------------------------------------------------------
  #absences are hotspots that DO NOT intersect a 5 km buffer around each occurrence point.
  
  sp.hotspots <- st_intersection(hotspots, sp.mcp) 
  
  presence.buffer <- st_buffer(sp.occ.sf, dist = 5000, endCapStyle = 'ROUND')
  
  absence.data <- st_difference(sp.hotspots, st_union(presence.buffer))
  
  print(paste0(bird.name, "-generate absence data - done"))
  
  
  #refine EOO by species elevational limits ---------------------------------------------------
  
  mcp.spatial <- as_Spatial(sp.mcp)
  sp.mcp.terra <- terra::vect(sp.mcp)
  
  dem.crop <- terra::crop(dem, ext(mcp.spatial))
  
  sp.mcp.ras <- terra::rasterize(sp.mcp.terra, dem.crop)
  dem.sp <- terra::mask(dem.crop, mask = sp.mcp.terra)
  
  #obtain elevation for each point
  ele_values <- terra::extract(dem, st_coordinates(sp.occ.sf), method = 'simple', list = FALSE)
  
  qntl <- round(stats::quantile(ele_values$SRTM_W_250m_eck4,
                                probs = c(0.25, 0.975), na.rm = TRUE), digits = 0)
  
  m <- c(-Inf, qntl[[1]], 0, qntl[[1]], 
         qntl[[2]], 1, qntl[[2]], Inf, 0)
  rclmat <- matrix(m, ncol=3, byrow=TRUE)
  
  sp.range <- terra::classify(dem.sp, rclmat) %>% 
    terra::aggregate(fact = 4, fun = 'max')
  
  sp.range[sp.range == 0] <- NA
  
  terra::writeRaster(sp.range, here("output", paste0(bird.name,"_range.tif")), 
                     overwrite = TRUE, wopt = list(datatype = 'INT1U', gdal="COMPRESS=LZW"))
  
  print(paste0(bird.name, "-obtain species range - done"))
  
  # subset absences and presences within the species range ---------------------
  
  #convert range to polygon
  sp.range.spat <- as.polygons(sp.range)
  sp.range.poly <- st_as_sf(sp.range.spat) %>% st_make_valid()
  
  #intersect  
  presences <- st_intersection(sp.occ.sf, sp.range.poly)
  absences <- st_intersection(absence.data, sp.range.poly)
  
  st_write(presences, here("output", paste0(bird.name, "_presences.gpkg")), delete_layer = TRUE)
  st_write(absences, here("output", paste0(bird.name, "_absences.gpkg")), delete_layer = TRUE)
  
  # Produce range with absence data using inverse distance weight (IDW) interpolation --------------------------------------------------------
  
  presences.coords <- st_coordinates(presences)
  absences.coords <- st_coordinates(absences)
  
  set.seed(0)
  group_p <- kfold(presences.coords, 5)
  group_a <- kfold(absences.coords, 5)
  
  #store internal cross-validation results
  eval.folds = list()
  
  for (i in 1:5) {
    
    #for each fold 1-5, train model on 80% of the data and test on 20%
    
    #presences
    test_p <- presences.coords[group_p == i, ]
    train_p <- presences.coords[group_p != i, ]
    
    #absences
    test_a <- absences.coords[group_a == i, ]
    train_a <- absences.coords[group_a == i, ]
    
    #build model
    idw.train <- geoIDW(p=train_p, a=train_a, dissolve = TRUE)
    
    #evaluate
    idw.eval <- evaluate(p=test_p, a=test_a, idw.train)
    df <- data.frame(species = bird.name, fold_number = i, AUC = idw.eval@auc, 
                     threshold = idw.eval@t, idw.eval@confusion)
    eval_df <- tibble::add_column(df, Jaccard = df$tp / (df$fn + df$tp + df$fp), 
                                  .after = 'AUC') 
    eval_df$Jaccard  <- eval_df$tp / (eval_df$fn + eval_df$tp + eval_df$fp)
    eval.folds[[i]] <- dplyr::filter(eval_df, Jaccard == max(Jaccard))
    
  } 
  
  eval.results <- dplyr::bind_rows(eval.folds)
  
  idw <- dismo::geoIDW(p = presences.coords, a = absences.coords, dissolve = TRUE)
  sp.range.spatial <- as(sp.range, "Raster")
  sp.idw <- predict(sp.range.spatial, idw, mask = T)
  
  threshold <- mean(eval.results$threshold)
  
  idw.range <- mask(sp.idw >= threshold, sp.range.spatial)
  idw.range[idw.range == 0] <- NA
  
  raster::writeRaster(idw.range, here("output", paste0(bird.name,"_IDW_range.tif")),
                      format = 'GTiff', overwrite = TRUE, datatype = 'INT1U', options="COMPRESS=LZW")
  
  idw.range.rast <- rast(idw.range)
  idw.range.spat <- terra::as.polygons(idw.range.rast)
  
  idw.range.poly <- st_as_sf(idw.range.spat) %>% st_make_valid()
  
  st_write(idw.range.poly, here("output", paste0(bird.name, "_IDW_range.gpkg")), delete_layer = TRUE)
  print(paste0(bird.name, "-obtain IDW range - done"))
  
  # Generate AOH (Area of Habitat) ------------------------------------------
  
  AOH <- terra::crop(habitat, ext(idw.range.rast))
  sp.AOH <- terra::mask(AOH, idw.range.spat)
  sp.AOH[sp.AOH == 0] <- NA
  
  terra::writeRaster(sp.AOH, here("output", paste0(bird.name,"_AOH.tif")),
                     filetype = 'GTiff', overwrite = TRUE, wopt = list(datatype = 'INT1U', gdal="COMPRESS=LZW"))
  
  print(paste0(bird.name, "-obtain AOH - done"))
  
  raster::removeTmpFiles(h=0)
  terra::tmpFiles(remove=TRUE)
  
}
